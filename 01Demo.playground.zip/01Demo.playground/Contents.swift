import UIKit

var greeting = "Hello, playground"

print("Hi",10,12.25)
print(greeting)
//String interpolation
//  \(variableName)
var language = "Swift"
print("I dont like \(language)")



var age = 23
print("You are \(age) years old and in another \(age) years, you will be \(age * 2)")
      
var name = "Bhaskar"
var grade = 88
print("Hello, \(name)! Your grade is \(grade)")
      
    
print("""
Hello
World!
""")
      
print ("Hello All,\rWelcome to Swift programming")

let  welcomeMessage : String = "Hello!"
   print(welcomeMessage , "All")

print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")

var name1 = "Sharma"
var grade1 = 88
print("Hello, \(name1)! Your grade is \(grade1), terminator: ")

//Declaration of variable
var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)

let pi = 3.14
print(pi)

var age1 : Int = 23
age = age * 2
print(age)

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")


var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)

print(10,20,30)
    print(12.5,15.5)

var httpError  = (errorCode : 404  , errorMessage : "Page  Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )

var name2 = ("John","Smith")
var fName = name2.0
var lName = name2.1
print(fName , terminator : ",")
print(lName)

var origin = (x : 0 , y : 0)
var point = origin
print(point)

let city = (name : "Maryville" , population : 6000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)

let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

var fname = "Bhaskar"
var lname = "Bobbala"
(fname , lname) = (lname , fname)
print("First Name is \(fname) and Last Name is \(lname)")

var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
